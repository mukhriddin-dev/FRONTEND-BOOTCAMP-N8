const OneEducation = () => {
  return <div>OneEducation</div>;
};

export default OneEducation;
