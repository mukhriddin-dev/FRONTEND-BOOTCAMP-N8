const SKILLS = "skills";
const USER = "user";
const ENDPOINT = "https://ap-portfolio-backend.up.railway.app/";
const TOKEN = "PORTFOLIO_TOKEN";
const ROLE = "PORTFOLIO_ROLE";
const LIMIT = 10;
const IS_LOGIN = "IS_LOGIN";

export { SKILLS, ENDPOINT, TOKEN, LIMIT, USER, IS_LOGIN, ROLE };
